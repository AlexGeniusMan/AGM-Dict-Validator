from setuptools import setup

setup(name='agm_dict_validator',
      version='0.0.1',
      description='Custom dict validator',
      packages=['agm_dict_validator'],
      author_email='alexgeniusman@gmail.com',
      zip_safe=False)
